// routes/studentRoutes.js
const express = require('express');
const router = express.Router();
const Student = require('../models/studentModel');

// ------------------- CREATE -------------------
router.post('/', async (req, res, next) => {
  try {
    const student = new Student(req.body);
    const saved = await student.save();
    res.status(201).json({ message: 'Student created successfully ✅', saved });
  } catch (err) {
    err.statusCode = 400;
    next(err);
  }
});

// ------------------- READ ALL -------------------
router.get('/', async (req, res, next) => {
  try {
    const students = await Student.find();
    res.status(200).json(students);
  } catch (err) {
    err.statusCode = 500;
    next(err);
  }
});

// ------------------- READ ONE -------------------
router.get('/:id', async (req, res, next) => {
  try {
    const student = await Student.findById(req.params.id);
    if (!student) {
      const error = new Error('Student not found ❌');
      error.statusCode = 404;
      throw error;
    }
    res.status(200).json(student);
  } catch (err) {
    err.statusCode = err.statusCode || 400;
    next(err);
  }
});

// ------------------- UPDATE -------------------
router.put('/:id', async (req, res, next) => {
  try {
    const updated = await Student.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!updated) {
      const error = new Error('Student not found ❌');
      error.statusCode = 404;
      throw error;
    }
    res.status(200).json({ message: 'Student updated successfully ✏️', updated });
  } catch (err) {
    err.statusCode = err.statusCode || 400;
    next(err);
  }
});

// ------------------- DELETE -------------------
router.delete('/:id', async (req, res, next) => {
  try {
    const deleted = await Student.findByIdAndDelete(req.params.id);
    if (!deleted) {
      const error = new Error('Student not found ❌');
      error.statusCode = 404;
      throw error;
    }
    res.status(200).json({ message: 'Student deleted successfully 🗑️' });
  } catch (err) {
    err.statusCode = err.statusCode || 400;
    next(err);
  }
});

module.exports = router;
